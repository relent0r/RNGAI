
Tooltips = {
    aitype_RNGStandard = {
        title = "<LOC RNG_0001>AI: RNG Standard",
        description = "<LOC RNG_0002>Standard AI.",
    },
    aitype_RNGStandardcheat = {
        title = "<LOC RNG_0003>AIx: RNG Standard",
        description = "<LOC RNG_0004>Standard AI using cheat options .",
    },
}