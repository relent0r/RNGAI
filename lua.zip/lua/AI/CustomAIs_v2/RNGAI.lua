

AI = {
    Name = "RNGAI",
    Version = "1",
    AIList = {
        {
            key = 'RNGStandard',
            name = "<LOC RNG_0001>AI: RNG Standard",
        },
        --{
        --   key = 'RNGStandardnull',
        --    name = "<LOC RNG_0001>AI: RNG Standardnull",
        --},
    },
    -- key names must have the word "cheat" included, or we won't get omniview
    CheatAIList = {
        {
            key = 'RNGStandardcheat',
            name = "<LOC RNG_0003>AIx: RNG Standard",
        },
        --{
        --   key = 'RNGStandardnullcheat',
        --    name = "<LOC RNG_0003>AIx: RNG Standardnull",
       --},
    },
}