﻿
RNGAI_0001="AI : RNGAI Standard"
RNGAI_0002="Good for 10km or smaller maps."
RNGAI_0003="AIx: RNGAI Standard"
RNGAI_0004="Good for 10km or smaller maps."

-- Translation strings for your AI lobby options.
aisettingsRNG_0200="Enable Threat Debug"
aisettingsRNG_0201="Display live threat updates when a player is focused on"
aisettingsRNG_0202="On"
aisettingsRNG_0203="help text on"
aisettingsRNG_0204="Off"
aisettingsRNG_0205="help text off"
